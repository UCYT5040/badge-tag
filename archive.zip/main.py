import badge
import utime
import math
import urandom as random

# Configuration
SCREEN_WIDTH = 128
SCREEN_HEIGHT = 64
MAX_DISTANCE = 50  # Maximum distance in meters for RSSI conversion
RANDOMNESS = 5     # RSSI randomness factor

# MicroPython compatibility
if not hasattr(utime, 'ticks_ms'):
    utime.ticks_ms = lambda: utime.ticks_ms()
    utime.ticks_diff = lambda a, b: a - b

class BeaconLocalizer:
    def __init__(self):
        """Initialize without predefined base stations"""
        self.known_devices = {}  # Maps device_id to (x, y, last_seen)
        self.rssi_readings = {}  # Maps device_id to (rssi, timestamp)
        self.position = (0, 0)   # Current estimated position
        self.last_update = 0
        self._rssi_to_m = 0.3   # Approximate RSSI to meters conversion factor
        
    def update_rssi(self, device_id, rssi, timestamp):
        """Update RSSI reading from a device"""
        self.rssi_readings[device_id] = (rssi, timestamp)
        
        # If this is a known device, update its last seen time
        if device_id in self.known_devices:
            x, y, _ = self.known_devices[device_id]
            self.known_devices[device_id] = (x, y, timestamp)
    
    def add_known_device(self, device_id, x, y, timestamp):
        """Add a device with known position"""
        self.known_devices[device_id] = (x, y, timestamp)
        
    def _rssi_to_distance(self, rssi):
        """Convert RSSI to approximate distance in meters"""
        # Simple model - adjust these values based on your environment
        tx_power = -40  # RSSI at 1 meter
        n = 2.0         # Path loss exponent (2=free space, higher=more lossy)
        
        if rssi >= 0:
            return 0
            
        ratio = rssi * 1.0 / tx_power
        if ratio < 1.0:
            return ratio ** 10
        else:
            return (0.89976) * (ratio ** 7.7095) + 0.111
    
    def estimate_position(self):
        """Estimate position based on nearby devices"""
        current_time = utime.ticks_ms()
        valid_devices = []
        
        # Find devices with recent RSSI readings
        for device_id, (rssi, timestamp) in self.rssi_readings.items():
            # Only use readings from the last 5 seconds
            if utime.ticks_diff(current_time, timestamp) < 5000 and device_id in self.known_devices:
                valid_devices.append(device_id)
        
        if len(valid_devices) < 1:
            return None
            
        # Simple weighted average of known device positions
        total_x = 0
        total_y = 0
        total_weight = 0
        
        for device_id in valid_devices:
            x, y, _ = self.known_devices[device_id]
            rssi, _ = self.rssi_readings[device_id]
            
            # Use inverse square of distance as weight
            # Closer devices have more influence
            distance = self._rssi_to_distance(rssi)
            if distance <= 0:
                weight = 1.0
            else:
                weight = 1.0 / (distance * distance)
            
            total_x += x * weight
            total_y += y * weight
            total_weight += weight
        
        if total_weight > 0:
            self.position = (int(total_x / total_weight), int(total_y / total_weight))
            return self.position
            
        return None

class App(badge.BaseApp):
    def __init__(self) -> None:
        self.got_packet = False
        self.packet = None
        self.last_rssi = 0
        self.device_id = random.getrandbits(32)  # Random device ID
        self.is_anchor = False  # Set to True for devices with known positions
        self.position = None  # Current position (None if unknown)
        self.last_broadcast = 0
        
        # Initialize localizer
        self.localizer = BeaconLocalizer()
        
        # If this is an anchor, set its position
        if self.is_anchor:
            # For demo, use random position - in real use, set fixed coordinates
            self.position = (random.randint(0, 100), random.randint(0, 100))
            self.localizer.add_known_device(self.device_id, *self.position, utime.ticks_ms())

    def on_open(self) -> None:
        badge.display.fill(1)
        badge.display.text("Beacon Localization", 10, 10, 0)
        if self.is_anchor:
            badge.display.text("Anchor Node", 10, 25, 0)
            badge.display.text(f"ID: {self.device_id:08X}", 10, 40, 0)
            badge.display.text(f"Pos: {self.position}", 10, 55, 0)
        else:
            badge.display.text("Mobile Node", 10, 25, 0)
            badge.display.text(f"ID: {self.device_id:08X}", 10, 40, 0)
        badge.display.show()
    
    def on_packet(self, packet: badge.radio.Packet, is_foreground: bool) -> None:
        try:
            data = packet.data.decode()
            if data.startswith("BEACON:"):
                parts = data.split(':')
                if len(parts) >= 5:  # BEACON:DEVICE_ID:POS_X:POS_Y:TIMESTAMP
                    device_id = int(parts[1])
                    pos_x = int(parts[2])
                    pos_y = int(parts[3])
                    timestamp = int(parts[4])
                    
                    # Only process if this is a new or updated device
                    if device_id != self.device_id:  # Ignore our own packets
                        rssi = sx.getRSSI()
                        self.localizer.update_rssi(device_id, rssi, utime.ticks_ms())
                        self.localizer.add_known_device(device_id, pos_x, pos_y, timestamp)
                        self.got_packet = True
        except Exception as e:
            print("Error processing packet:", e)

    def loop(self):
        current_time = utime.ticks_ms()
        
        try:
            # Broadcast our position if we know it or are an anchor
            if (self.position is not None or self.is_anchor) and \
               (not hasattr(self, 'last_broadcast') or utime.ticks_diff(current_time, self.last_broadcast) > 2000):
                # Create message efficiently for MicroPython
                msg = "BEACON:{}:{}:{}:{}".format(
                    self.device_id,
                    self.position[0] if self.position else 0,
                    self.position[1] if self.position else 0,
                    current_time
                )
                badge.radio.send_packet(dest=0xFFFF, data=msg)
                self.last_broadcast = current_time
            
            # Update display
            badge.display.fill(1)
            
            if self.is_anchor:
                self._draw_text("Anchor Mode", 10, 10)
                self._draw_text("ID: {:08X}".format(self.device_id), 10, 25)
                self._draw_text("Pos: {},{}".format(*self.position), 10, 40)
            else:
                # Try to estimate position
                estimated_pos = self.localizer.estimate_position()
                if estimated_pos:
                    self.position = estimated_pos
                    self._draw_text("Mobile Mode", 10, 10)
                    self._draw_text("Pos: {},{}".format(*estimated_pos), 10, 25)
                else:
                    self._draw_text("No position", 10, 10)
                    self._draw_text("Need more nodes", 10, 25)
            
            # Show nearby devices
            y_pos = 55
            for dev_id, (rssi, timestamp) in self.localizer.rssi_readings.items():
                if utime.ticks_diff(current_time, timestamp) < 5000:  # Only show recent readings
                    if dev_id in self.localizer.known_devices:
                        self._draw_text("D{:04X}: {}dB".format(dev_id % 0xFFFF, rssi), 10, y_pos)
                        y_pos += 10
                        if y_pos > 100:  # Don't go off screen
                            break
            
            badge.display.show()
            
        except Exception as e:
            # Basic error handling
            badge.display.fill(1)
            self._draw_text("Error:", 10, 10)
            self._draw_text(str(e)[:20], 10, 25)
            badge.display.show()
            
        utime.sleep_ms(500)  # Reduce CPU usage
    
    def _draw_text(self, text, x, y):
        """Helper to draw text with error handling"""
        try:
            badge.display.text(text, x, y, 0)
        except:
            # If text is too long or invalid, try to show something
            badge.display.text(str(text)[:20], x, y, 0)